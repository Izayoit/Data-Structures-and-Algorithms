/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author User
 */
public class Cliente {
    String  codigo;
    String DNI ;
    String apellidos; 
    String nombres ;
    String direccion ;
    String telefono ;
    private static int contador =1 ;
    
    
    public String generado(){
        
    return "Cliente N°"+contador ;
        
    };

    public Cliente( String DNI, String apellidos, String nombres, String direccion, String telefono) {
        codigo = generado();
        this.DNI = DNI;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.direccion = direccion;
        this.telefono = telefono;
    }

   

    public Cliente(String nombres) {
        this.nombres = nombres;
    }
    
    
    public Object[] getRegistro(){
        return new Object[]{
            codigo,DNI ,apellidos,nombres,direccion,telefono 
        } ;
    }
    
    public String getcadena(){
        
        return DNI +codigo + apellidos+nombres+direccion+telefono ;
    };
    
    
    public String datos(){
        
        return apellidos + "  "+ nombres ;
    }
    
    
    
    
    
    
    
    
    
    public Object[] getRegsitro(){
        
        return new Object[] {
            
            codigo,apellidos,nombres,direccion,telefono
        };
        
        
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public static int getContador() {
        return contador;
    }

    public static void setContador(int contador) {
        Cliente.contador = contador;
    }
    
    
    
    
    
    
    
    
    
    
}
