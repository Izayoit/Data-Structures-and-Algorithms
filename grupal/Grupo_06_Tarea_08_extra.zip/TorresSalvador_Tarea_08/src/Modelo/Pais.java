/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Control.Lista_Ciudad;

/**
 *
 * @author User
 */
public class Pais {
    
    String codigo ;
    String Nombre_Pais ;
    Lista_Ciudad Lisra_ciudad ;
    private static int contador = 1 ;
    
    public String codigo(){
        
        return "Pais :  " +contador++ ;
    }

    public Pais(String nombre_pais) {
      this.codigo =codigo() ;
      this.Nombre_Pais = nombre_pais;
      Lisra_ciudad  = new Lista_Ciudad();
      
    }
    
    public Object[ ] getRegistro(){
        
        return new Object[]{
            codigo, Nombre_Pais
        };
    }
    
    
    public String getCadena(){
        
        return codigo+Nombre_Pais+Lisra_ciudad ;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre_Pais() {
        return Nombre_Pais;
    }

    public void setNombre_Pais(String Nombre_Pais) {
        this.Nombre_Pais = Nombre_Pais;
    }

    public Lista_Ciudad getLisra_ciudad() {
        return Lisra_ciudad;
    }

    public void setLisra_ciudad(Lista_Ciudad Lisra_ciudad) {
        this.Lisra_ciudad = Lisra_ciudad;
    }

    public static int getContador() {
        return contador;
    }

    public static void setContador(int contador) {
        Pais.contador = contador;
    }
    
    
    
    
    
    
}
