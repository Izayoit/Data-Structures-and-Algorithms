/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Control.Pila_Boletos;
import java.util.Date;

/**
 *
 * @author User
 */
public class Vuelo {
    
     
    
    String codigo ;
    String fecha ;
     String hora ;
     Pais objPais ;
     Ciudad obj_ciudad ;
     double precio ;
     int capacidad ;
     public static  int contador =1 ;
     
      Pila_Boletos ListaBoletos ;
    public Vuelo(String fecha, String hora, Pais objPais, Ciudad obj_ciudad, double precio, int capacidad) {
        
        codigo =generador();
        this.fecha = fecha;
        this.hora = hora;
        this.objPais = objPais;
        this.obj_ciudad = obj_ciudad;
        this.precio = precio;
        this.capacidad = capacidad;
        this.ListaBoletos = new Pila_Boletos();
    }

    public Vuelo(String codigo) {
        this.codigo = codigo;
    }
    
    
    
    
    public String generador( ){
        
        return "VUE" +contador++ ;
        
    }
    
    public String getCadena(){
       return codigo +fecha +hora+objPais.getNombre_Pais()+obj_ciudad.getNombre_ciudad()+precio+capacidad  ;
    };
    
    
    
    public String datos_combo(){
        
        return codigo+ "-"+obj_ciudad.getNombre_ciudad()+"-"+objPais.getNombre_Pais()+"-"+fecha+"-"+hora ;
        
    }
    
    
    

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public static int getContador() {
        return contador;
    }

    public static void setContador(int contador) {
        Vuelo.contador = contador;
    }
     
     
     
     
     
     public Object[] getRegistro(){
         return new Object[]{
             codigo ,fecha,hora,objPais.getNombre_Pais(),obj_ciudad.getNombre_ciudad(),precio,capacidad
         };
     }

    public Pila_Boletos getListaBoletos() {
        return ListaBoletos;
    }

    public void setListaBoletos(Pila_Boletos ListaBoletos) {
        this.ListaBoletos = ListaBoletos;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }
     
     
     

   

    public Pais getObjPais() {
        return objPais;
    }

    public void setObjPais(Pais objPais) {
        this.objPais = objPais;
    }

    public Ciudad getObj_ciudad() {
        return obj_ciudad;
    }

    public void setObj_ciudad(Ciudad obj_ciudad) {
        this.obj_ciudad = obj_ciudad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }
     
     
     
     

    
    
}
