/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author User
 */
public class Ciudad {

    String pais;
    String codigo;
    String nombre_ciudad;
    public static int contador = 1;

    public String generador() {
        return "Ciudadad : " + contador++;
    }

    public Ciudad(String nombre_ciudad, String pais) {

        codigo = generador();
        this.nombre_ciudad = nombre_ciudad;
        this.pais = pais;

    }

    public String getCadena() {
        return codigo + nombre_ciudad;
    }

    public Object[] getRegistro() {
        return new Object[]{
            codigo, nombre_ciudad, pais
        };
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre_ciudad() {
        return nombre_ciudad;
    }

    public void setNombre_ciudad(String nombre_ciudad) {
        this.nombre_ciudad = nombre_ciudad;
    }

    public static int getContador() {
        return contador;
    }

    public static void setContador(int contador) {
        Ciudad.contador = contador;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

}
