/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.Date;

/**
 *
 * @author User
 */
public class Boleto {
    
    
    String numero_boleto ;
    String fecha  ;
    String Hora ;
    Vuelo objVuelo ;
    Cliente objCliente ;
    String Num_asiento ;
     public static int contador =1 ;

    public Boleto(String fecha, String Hora, Vuelo objVuelo, Cliente objCliente, String Num_asiento) {
        
        numero_boleto = generador();
        this.fecha = fecha;
        this.Hora = Hora;
        this.objVuelo = objVuelo;
        this.objCliente = objCliente;
        this.Num_asiento = Num_asiento;
    }
    
    

    
    public String generador (){
        return "abc"+contador++;
    }
    
    
    
    public Object[] getRegistro(){
        return new Object[]{
            numero_boleto,fecha,Hora,objVuelo.getCodigo() ,objCliente.getNombres() ,Num_asiento
                
        };
    }
    
    
   
    
    
    public String getCadena(){
        
        return numero_boleto +fecha+Hora+objVuelo+objCliente+Num_asiento ;
    }

    public String getNumero_boleto() {
        return numero_boleto;
    }

    public void setNumero_boleto(String numero_boleto) {
        this.numero_boleto = numero_boleto;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String Hora) {
        this.Hora = Hora;
    }

   


    public Vuelo getObjVuelo() {
        return objVuelo;
    }

    public void setObjVuelo(Vuelo objVuelo) {
        this.objVuelo = objVuelo;
    }

    public Cliente getObjCliente() {
        return objCliente;
    }

    public void setObjCliente(Cliente objCliente) {
        this.objCliente = objCliente;
    }

    public String getNum_asiento() {
        return Num_asiento;
    }

    public void setNum_asiento(String Num_asiento) {
        this.Num_asiento = Num_asiento;
    }

    public static int getContador() {
        return contador;
    }

    public static void setContador(int contador) {
        Boleto.contador = contador;
    }
            

    
    
    
    
    
    
    
    
    
}
