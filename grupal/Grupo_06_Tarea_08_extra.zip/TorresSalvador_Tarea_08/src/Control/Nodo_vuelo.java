/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.Vuelo;

/**
 *
 * @author User
 */
public class Nodo_vuelo {
    Vuelo datos ;

    Nodo_vuelo siguiente ;

    public Nodo_vuelo(Vuelo datos) {
        this.datos = datos;
    }

    public Vuelo getDatos() {
        return datos;
    }

    public void setDatos(Vuelo datos) {
        this.datos = datos;
    }

    public Nodo_vuelo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo_vuelo siguiente) {
        this.siguiente = siguiente;
    }
    
    
    
}
