/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.Ciudad;
import Modelo.Cliente;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class Lista_Ciudad {

    Nodo_Ciudad fin;

    public Lista_Ciudad() {
        fin = null;
    }

    public Nodo_Ciudad getFin() {
        return fin;
    }

    public void setFin(Nodo_Ciudad fin) {
        this.fin = fin;
    }

    public void registrar(Ciudad dato, String nombre) {

        if (seEncuentra(nombre)) {
            JOptionPane.showMessageDialog(null, "Ciudad ya registrada");
            return;
        }

        Nodo_Ciudad nuevo = new Nodo_Ciudad(dato);

        nuevo.setSiguiente(fin);

        fin = nuevo;

    }

    public void ListarCbo(JComboBox cbo) {

        DefaultComboBoxModel modcombo = new DefaultComboBoxModel();
        cbo.setModel(modcombo);
        Nodo_Ciudad aux = fin;

        while (aux != null) {

            modcombo.addElement(aux.getDatos().getNombre_ciudad());

            aux = aux.getSiguiente();

        }

    }
    
    public void eliminar(String nombre){
        Nodo_Ciudad actual = fin ;
       Nodo_Ciudad anterior = null ;
        
        while (actual!=null) {    
            
            if (actual.getDatos().getNombre_ciudad().equals(nombre)) {
               
                  fin= actual.getSiguiente();
                    
               
                
                
            }else{
                anterior.setSiguiente(actual.getSiguiente());
            }
            
                JOptionPane.showMessageDialog(null, "Ciudad eliminada");
          return ;
        }
        anterior = actual ;
        JOptionPane.showMessageDialog(null, "Ciudad no encontrada");

        
    }
    
    
    public Nodo_Ciudad Obtener(String nombre){
        
        Nodo_Ciudad aux = fin;
        
        while (aux!=null) {            
            if (aux.getDatos().getNombre_ciudad().equals(nombre)) {
                return aux ;
            }
            aux = aux.getSiguiente();
        }
        return null ;
    }
    
    
    public void Editar(String nombreViejo ,Ciudad nuevoDato){
        
        
        Nodo_Ciudad actual = fin ;
         while (actual!=null) {            
             if (actual.getDatos().getNombre_ciudad().equals(nombreViejo)) {
                 actual.setDatos(nuevoDato);
                 JOptionPane.showMessageDialog(null,"Ciudad Editada");
                 return ;
             
             }
             
             actual = actual.getSiguiente();
        }
        
        JOptionPane.showMessageDialog(null, "Ciudad no encontrada");
    }
    
    
    
    
    

   

    public void Filtrar(String filtro, JTable tabla) {

        String cabecera[] = {
            "Codigo", "Nombre_Ciudad", "Pais"
        };

        DefaultTableModel modtabla = new DefaultTableModel(cabecera, 0);
        tabla.setModel(modtabla);

        Nodo_Ciudad aux = fin;

        while (aux != null) {

            if (aux.getDatos().getCadena().contains(filtro)) {
                modtabla.addRow(aux.getDatos().getRegistro());
            }
            aux = aux.getSiguiente();

        }

    }

    public void Listar(JTable tabla) {
        String cabecera[] = {"Codigo", "Nombre_Ciudad", "Pais"};
        DefaultTableModel modtabla = new DefaultTableModel(cabecera, 0);
        tabla.setModel(modtabla);

        Nodo_Ciudad aux = fin;

        while (aux != null) {
            modtabla.addRow(aux.getDatos().getRegistro());
            aux = aux.getSiguiente();
        }

    }

    public boolean seEncuentra(String nombre) {

        Nodo_Ciudad aux = fin;

        if (aux != null) {
            do {

                if (aux.getDatos().getNombre_ciudad().equals(nombre)) {
                    return true;
                }

                aux = aux.getSiguiente();

            } while (aux != null);

        }
        return false;
    }

}
