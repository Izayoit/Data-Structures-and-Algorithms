/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.Cliente;

/**
 *
 * @author User
 */
public class Nodo_Cliente {
    
    Cliente elementos ;
    
    Nodo_Cliente    siguiente ;   

    public Nodo_Cliente(Cliente elementos) {
        this.elementos = elementos;
        
        siguiente = null ;
    }

    public Cliente getElementos() {
        return elementos;
    }

    public void setElementos(Cliente elementos) {
        this.elementos = elementos;
    }

    public Nodo_Cliente getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo_Cliente siguiente) {
        this.siguiente = siguiente;
    }

    
    
    
    
    
}
