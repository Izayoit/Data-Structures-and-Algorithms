/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.Boleto;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class Pila_Boletos {
    
    Nodo_Boleto Cima ;

    public Pila_Boletos() {
        Cima = null ;
    }

    public Nodo_Boleto getCima() {
        return Cima;
    }

    public void setCima(Nodo_Boleto Cima) {
        this.Cima = Cima;
    }

    
    
    public void apilar(Boleto dato){
        
        Nodo_Boleto nuevo =new Nodo_Boleto(dato) ;
       nuevo.setSiguiente(Cima);
       Cima = nuevo ;
        
    }
    
    public  Boleto desapilar(){
        
        
        Boleto dat = Cima.getDatos();
        Cima = Cima.getSiguiente();
        
        return dat ;
        
    }
    
    public void filtrar(String filtro,JTable tabla){
        String cabecera[]={
           "N°Boleto","Fechs","Hora","Vuelo","Cliente","N°Asiento"
       } ;
       
        DefaultTableModel modtabla = new DefaultTableModel(cabecera, 0);
        tabla.setModel(modtabla);
        Nodo_Boleto aux = Cima ;
        
        
        while (aux!=null) {    
            
            if (aux.getDatos().getCadena().contains(filtro)) {
                modtabla.addRow(aux.getDatos().getRegistro());
            }
            aux = aux.getSiguiente();
        }
        
        
        
    }
    
    
    
    
    
    public void Listar(JTable tabla){
        
       String cabecera[]={
           "N°Boleto","Fechs","Hora","Vuelo","Cliente","N°Asiento"
       } ;
       
        DefaultTableModel modtabla = new DefaultTableModel(cabecera, 0);
        tabla.setModel(modtabla);
        
        
        Nodo_Boleto aux = Cima ;
        while (aux!=null) {   
            
            modtabla.addRow(aux.getDatos().getRegistro());
            aux = aux.getSiguiente();
            
        }
        
        
        
        
    }
    
    
    
    
    
}
