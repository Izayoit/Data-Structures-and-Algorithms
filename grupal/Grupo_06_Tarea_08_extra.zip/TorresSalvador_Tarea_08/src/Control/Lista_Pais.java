/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.Pais;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class Lista_Pais {

    Nodo_Pais inicio, fin;

    public Lista_Pais() {
        inicio = fin = null;
    }

    public Nodo_Pais getInicio() {
        return inicio;
    }

    public void setInicio(Nodo_Pais Inicio) {
        this.inicio = Inicio;
    }

    public Nodo_Pais getFin() {
        return fin;
    }

    public void setFin(Nodo_Pais Fin) {
        this.fin = Fin;
    }

    public void Registrar(Pais Datos, int pos,String nombre) {

        Nodo_Pais nuevo = new Nodo_Pais(Datos);
    
        if (!existe(nombre)) {
            
                    if (inicio == null) {

            inicio = fin = nuevo;

        } else if (pos < 0) {
            fin.setSiguiente(nuevo);
            nuevo.setAnterior(fin);
            fin = nuevo;

        } else {

            Nodo_Pais actual = inicio;

            for (int i = 0; i < pos; i++) {
                actual = actual.getSiguiente();

            }

            Nodo_Pais siguiente = actual.getSiguiente();
            actual.setSiguiente(nuevo);
            nuevo.setAnterior(actual);
            nuevo.setSiguiente(siguiente);
            siguiente.setAnterior(nuevo);

        }

        fin.setSiguiente(inicio);
        inicio.setAnterior(fin);

        }else{
            JOptionPane.showMessageDialog(null, "Ya existe el Pais");
        }
        
        
        
        
    }

    public Nodo_Pais Obtener(String codigo) {

        Nodo_Pais aux = inicio;
        if (aux != null) {
            do {

                if (aux.getElementos().getCodigo().equals(codigo)) {

                    return aux;

                }
                aux = aux.getSiguiente();

            } while (aux != inicio);

        }

        return null;

    }

    public void Listar(JTable tabla) {
        String[] cabcera = {
            "Codigo", "NombrePais"
        };
        DefaultTableModel modtabla = new DefaultTableModel(cabcera, 0);
        tabla.setModel(modtabla);

        Nodo_Pais aux = inicio;

        if (aux!=null) {
             do {

            modtabla.addRow(aux.getElementos().getRegistro());
            aux = aux.getSiguiente();

        } while (aux != inicio);
            
        }

    }
    
    
       public void ListarCbo(JComboBox cbo) {
        
        DefaultComboBoxModel modcombo = new DefaultComboBoxModel();
        cbo.setModel(modcombo);

        Nodo_Pais aux = inicio;

        if (aux!=null) {
              do {

            modcombo.addElement(aux.elementos.getNombre_Pais());
            aux = aux.getSiguiente();

        } while (aux != inicio&&aux!=null);
        }

    }
       
       public boolean existe(String nombre){
           
           Nodo_Pais  aux = inicio ;
           
           if (aux!=null) {
               
               do {                   
                   
                   
                   if (aux.getElementos().getNombre_Pais().equals(nombre)) {
                       return true ;
                   }
                   aux= aux.getSiguiente() ;
                   
               } while (aux!=inicio);
               
               
           }
           
           return false;
       }
    
    
    

    public void Filtrar(JTable tabla, String filtro) {

        String[] cabcera = {
            "Codigo", "NombrePais"
        };
        DefaultTableModel modtabla = new DefaultTableModel(cabcera, 0);
        tabla.setModel(modtabla);

        Nodo_Pais aux = inicio;
        do {

            if (aux.getElementos().getCadena().contains(filtro)) {
                modtabla.addRow(aux.getElementos().getRegistro());

            }

            aux = aux.getSiguiente();

        } while (aux != inicio);

    }
    
    
    public   void  Editar(Nodo_Pais Editado,String nombre){
        
     Editado.getElementos().setNombre_Pais(nombre);
        
    }
    

 
 public boolean estaVacia(){
     return inicio== null ;
 }
 

    public boolean eliminarPorCodigo(String codigo) {
        if (estaVacia()) {
            return false;
        }
        Nodo_Pais aux = inicio;
        do {
            if (aux.getElementos().getCodigo().equals(codigo)) {
                if (inicio == fin) {
                    inicio = fin = null;
                } else {
                    aux.anterior.siguiente = aux.siguiente;
                    aux.siguiente.anterior = aux.anterior;
                    if (aux == inicio) {
                        inicio = aux.siguiente;
                    }
                    if (aux == fin) {
                        fin = aux.anterior;
                    }
                }
                return true;
            }
            aux = aux.siguiente;
        } while (aux != inicio);
        return false;
    }
    

}
