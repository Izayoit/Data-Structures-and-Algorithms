/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.Cliente;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class Lista_Cliente {

    Nodo_Cliente inicio, fin;

    public Lista_Cliente() {

        inicio = fin = null;

    }

    public Nodo_Cliente getInicio() {
        return inicio;
    }

    public void setInicio(Nodo_Cliente inicio) {
        this.inicio = inicio;
    }

    public Nodo_Cliente getFin() {
        return fin;
    }

    public void setFin(Nodo_Cliente fin) {
        this.fin = fin;
    }

    public void Registrar(Cliente cliente) {

        Nodo_Cliente NUEVO = new Nodo_Cliente(cliente);

        if (inicio == null) {
            inicio = fin = NUEVO;
        } else {
            fin.setSiguiente(NUEVO);
            fin = NUEVO;

        }

    }
    
    public void eliminar(String nombre){
        Nodo_Cliente actual = inicio;
        Nodo_Cliente anterior = null ;
        
        
        
        while (actual!=null) {   
            
            if (actual.getElementos().getNombres().equals(nombre)) {
                if (anterior== null) {
                    inicio = actual.getSiguiente();
                    if (inicio ==null) {
                        fin = null ;
                    }
                }else{
                anterior.setSiguiente(actual.getSiguiente());
                
                if (actual==fin) {
                    
                    fin =anterior ;
                }
                
                
                
            }
                 JOptionPane.showMessageDialog(null, "Cliente eliminado");
            
            return ;
                
                
            }
            anterior = actual ;
            actual = actual.getSiguiente();
           
        }
        
        JOptionPane.showMessageDialog(null, "Cliente no encontrado");
        
        
    }


    
    
    public void editar(String Nombreviejo,Cliente nuevo){
        
        Nodo_Cliente aux = inicio ;
        
        while (aux!=null) {            
            if (aux.getElementos().getNombres().equals(Nombreviejo)) {
               aux.setElementos(nuevo);
               JOptionPane.showMessageDialog(null, "Cliente editado");
               return ;
            }
            
            aux = aux.getSiguiente();
        }
        JOptionPane.showMessageDialog(null, "Cliente no encontrado");
        
    }
    
    
    
   
  
    
    

    public void Listar(JTable tabla) {

        String cabcera[] = {
            "Codigo",  "Dni" , "Apellidos", "Nombres", "Direccion", "Telefono"
        };
        DefaultTableModel modtabla = new DefaultTableModel(cabcera, 0);
        tabla.setModel(modtabla);

        Nodo_Cliente aux = inicio;

        while (aux != null) {

            modtabla.addRow(aux.getElementos().getRegistro());
            aux = aux.getSiguiente();

        }

    }
    
    
    
 public void Filtrar(String filtro,JTable tabla){
     Nodo_Cliente aux = inicio ;
     String cabcera[] = {
            "Codigo",  "Dni" , "Apellidos", "Nombres", "Direccion", "Telefono"
        };
        DefaultTableModel modtabla = new DefaultTableModel(cabcera, 0);
        tabla.setModel(modtabla);

     
     while (aux!=null) {         
         if (aux.getElementos().getcadena().contains(filtro)) {
             modtabla.addRow(aux.getElementos().getRegistro());
         }
         aux = aux.getSiguiente();
     }
 }
    
    
    
  public void  Listar_cbo(JComboBox combito){
      
      DefaultComboBoxModel modcombo = new DefaultComboBoxModel();
      combito.setModel(modcombo);
      Nodo_Cliente aux = inicio ;
      while (aux!=null) {          
          modcombo.addElement(aux.getElementos().datos());
          aux = aux.getSiguiente();
          
      }
      
  }
  
  public void Listar_lista(JList lista){
      
      DefaultListModel MODLISTA = new DefaultListModel();
      lista.setModel(MODLISTA);
      
      Nodo_Cliente aux= inicio ;
      while (aux!=null) {     
          
          MODLISTA.addElement(aux.getElementos().datos());
          aux= aux.getSiguiente();
          
      }
      
  }
  

}
