/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.Ciudad;
import Modelo.Cliente;

/**
 *
 * @author User
 */
public class Nodo_Ciudad {
    
    
    Ciudad datos ;
  
    Nodo_Ciudad siguiente;

    public Nodo_Ciudad(Ciudad datos) {
        this.datos = datos;
        
       
        siguiente = this ;
        
               
      
    }

    public Ciudad getDatos() {
        return datos;
    }

    public void setDatos(Ciudad datos) {
        this.datos = datos;
    }

  
    public Nodo_Ciudad getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo_Ciudad siguiente) {
        this.siguiente = siguiente;
    }

    
    
    
}
