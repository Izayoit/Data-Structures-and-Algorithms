/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.Boleto;
import Modelo.Vuelo;

/**
 *
 * @author User
 */
public class Nodo_Boleto {

    Boleto  datos ;
    
    
    Nodo_Boleto siguiente ;

    public Nodo_Boleto(Boleto datos) {
        this.datos = datos;
        
        siguiente =null ;
    }

    public Boleto getDatos() {
        return datos;
    }

    public void setDatos(Boleto datos) {
        this.datos = datos;
    }

    public Nodo_Boleto getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo_Boleto siguiente) {
        this.siguiente = siguiente;
    }

   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
