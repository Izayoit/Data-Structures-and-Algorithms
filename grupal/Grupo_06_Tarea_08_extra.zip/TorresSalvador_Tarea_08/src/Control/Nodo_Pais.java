/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.Pais;

/**
 *
 * @author User
 */
public class Nodo_Pais {
    
    Pais elementos ;
    Nodo_Pais  anterior , siguiente ;

    public Nodo_Pais(Pais elementos) {
        this.elementos = elementos;
        anterior = siguiente = null ;
    }

    public Pais getElementos() {
        return elementos;
    }

    public void setElementos(Pais elementos) {
        this.elementos = elementos;
    }

    public Nodo_Pais getAnterior() {
        return anterior;
    }

    public void setAnterior(Nodo_Pais anterior) {
        this.anterior = anterior;
    }

    public Nodo_Pais getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo_Pais siguiente) {
        this.siguiente = siguiente;
    }
    
    
    
    
    
}
