/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.Vuelo;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class Cola_Vuelo {

    Nodo_vuelo Inicio, Fin;

    public Cola_Vuelo() {

        Inicio = Fin = null;

    }

    public Nodo_vuelo getInicio() {
        return Inicio;
    }

    public void setInicio(Nodo_vuelo Inicio) {
        this.Inicio = Inicio;
    }

    public Nodo_vuelo getFin() {
        return Fin;
    }

    public void setFin(Nodo_vuelo Fin) {
        this.Fin = Fin;
    }

    public void encolar(Vuelo datos) {

        Nodo_vuelo nuevo = new Nodo_vuelo(datos);

        if (Inicio == null) {
            Inicio = Fin = nuevo;
        } else {
            Fin.setSiguiente(nuevo);
            Fin = nuevo;

        }

    }

    public Vuelo desencolar() {

        Vuelo dat = Inicio.getDatos();
        Inicio = Inicio.getSiguiente();
        if (Inicio == null) {
            Fin = null;
        }
        return dat;

    }
    
    public void decapitar(){
        if (Inicio!=null) {
            Inicio = Inicio.getSiguiente();
            
            if (Inicio==null) {
                Fin=null ;
            }
        }
        
    }
    
    

    public void Listar(JTable tablota) {

        String cabcera[] = {
            "Codigo", "Fecha", "Hora", "Pais", "Ciudad", "Precio", "Capacidad"

        };

        DefaultTableModel modtabla = new DefaultTableModel(cabcera, 0);
        tablota.setModel(modtabla);
        Nodo_vuelo aux = Inicio;

        while (aux != null) {
            modtabla.addRow(aux.getDatos().getRegistro());
            aux = aux.getSiguiente();
        }

    }
    
    
    
    public void Listar_combo(JComboBox combo){
        
        DefaultComboBoxModel modcombo = new DefaultComboBoxModel();
        combo.setModel(modcombo);
        
        Nodo_vuelo aux = Inicio ;
        
        while (aux!=null) {            
            
            modcombo.addElement(aux.getDatos().datos_combo());
            aux= aux.getSiguiente();
        }
        
        
        
    }
    
    
    
    public void Listar_en_Lista(JList Lista){
        DefaultListModel modlista = new DefaultListModel();
        
        Lista.setModel(modlista);
        
        
        Nodo_vuelo aux = Inicio ;
         while (aux!=null) {            
            
             modlista.addElement(aux.getDatos().datos_combo());
             aux= aux.getSiguiente();
        }
        
        
    }
    
    
    public void editarCola(String codigo,Vuelo datos ){
        
        Nodo_vuelo  aux = Inicio ;
         while (aux!=null) {  
             
             if (aux.getDatos().getCodigo().equals(codigo)) {
                 
                 aux.getDatos().setFecha(datos.getFecha());
                 aux.getDatos().setHora(datos.getHora());
                 
                 aux.getDatos().getObjPais().setNombre_Pais(datos.getObjPais().getNombre_Pais());
                 aux.getDatos().setPrecio(datos.getPrecio());
                 aux.getDatos().setCapacidad(datos.getCapacidad());
                 aux.getDatos().getObj_ciudad().setNombre_ciudad(datos.getObj_ciudad().getNombre_ciudad());
             }
             
             aux = aux.getSiguiente() ;
            
        }
        
        
        
    }
    
    public void filtrar(String filtro,JTable tablota){
          String cabcera[] = {
            "Codigo", "Fecha", "Hora", "Pais", "Ciudad", "Precio", "Capacidad"

        };

        DefaultTableModel modtabla = new DefaultTableModel(cabcera, 0);
        tablota.setModel(modtabla);
        Nodo_vuelo aux = Inicio ;
        
        while (aux!=null) {            
            
            if (aux.getDatos().getCadena().contains(filtro)) {
                modtabla.addRow(aux.getDatos().getRegistro());
            }
            aux= aux.getSiguiente();
            
        }
        
        
    }
    
    

}
