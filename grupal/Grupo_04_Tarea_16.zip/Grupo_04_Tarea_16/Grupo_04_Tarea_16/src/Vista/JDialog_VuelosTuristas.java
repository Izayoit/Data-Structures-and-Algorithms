package Vista;

import Control.Arbol_Turista;
import Control.Arbol_ViajeContratado;
import Control.Arbol_VueloTurista;
import Control.Arbol_Vuelos;
import Control.DAO_Turistas;
import Control.DAO_ViajesContratados;
import Control.DAO_Vuelos;
import Control.DAO_VuelosTuristas;
import Modelo.VuelosTurista;
import java.util.HashMap;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

public class JDialog_VuelosTuristas extends javax.swing.JDialog {

    HashMap TablaHash1 = new HashMap();
    HashMap TablaHash2 = new HashMap();
    HashMap TablaHash3 = new HashMap();
    Arbol_VueloTurista objArbolVueloTurista = new Arbol_VueloTurista();
    Arbol_Turista objArbol_Turista = new Arbol_Turista();
    Arbol_Vuelos objArbol_Vuelos = new Arbol_Vuelos();
   
    Arbol_ViajeContratado objArbol_ViajeContratado = new Arbol_ViajeContratado();
    DefaultComboBoxModel comboCodigo = new DefaultComboBoxModel();

    public JDialog_VuelosTuristas(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        cbo_codigo.setModel(comboCodigo);
    }

    private void LimpiarCampos() {
        txt_clase.setText("");
        cbo_codviaje.setSelectedIndex(0);
        cbo_numVuelo.setSelectedIndex(0);
    }

    private void ActualizarTabla() {
        objArbolVueloTurista.Listar(tbl_vuelosturista);
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Opciones = new javax.swing.JPanel();
        btn_Registrar = new javax.swing.JButton();
        btn_Editar = new javax.swing.JButton();
        btn_Eliminar = new javax.swing.JButton();
        btn_Listar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_vuelosturista = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txt_clase = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        cbo_codigo = new javax.swing.JComboBox<>();
        cbo_numVuelo = new javax.swing.JComboBox<>();
        cbo_codviaje = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        Opciones.setBorder(javax.swing.BorderFactory.createTitledBorder("Opciones:"));
        Opciones.setLayout(new java.awt.GridLayout(4, 0, 0, 5));

        btn_Registrar.setText("Registrar");
        btn_Registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_RegistrarActionPerformed(evt);
            }
        });
        Opciones.add(btn_Registrar);

        btn_Editar.setText("Editar");
        btn_Editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_EditarActionPerformed(evt);
            }
        });
        Opciones.add(btn_Editar);

        btn_Eliminar.setText("Eliminar");
        btn_Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_EliminarActionPerformed(evt);
            }
        });
        Opciones.add(btn_Eliminar);

        btn_Listar.setText("Listar");
        btn_Listar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ListarActionPerformed(evt);
            }
        });
        Opciones.add(btn_Listar);

        tbl_vuelosturista.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_vuelosturista.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_vuelosturistaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_vuelosturista);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Registro de Estancias:"));

        jLabel1.setText("Clase:");

        jLabel2.setText("NumVuelo:");

        jLabel4.setText("Codigo viaje:");

        jLabel6.setText("codigo:");

        cbo_numVuelo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbo_codviaje.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabel2)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_clase)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(cbo_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 39, Short.MAX_VALUE)))
                        .addContainerGap())
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cbo_numVuelo, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbo_codviaje, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(cbo_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txt_clase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cbo_numVuelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(cbo_codviaje, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(62, 62, 62))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(Opciones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 554, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Opciones, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 438, Short.MAX_VALUE)
                        .addGap(72, 72, 72))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_RegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_RegistrarActionPerformed
        try {
            String clase = txt_clase.getText().trim();
            int codViaje = Integer.parseInt(cbo_codviaje.getSelectedItem().toString());
            int numVuelo = Integer.parseInt(cbo_numVuelo.getSelectedItem().toString());

            VuelosTurista nuevo = new VuelosTurista(new Object[]{0, clase, codViaje, numVuelo});

            objArbolVueloTurista.setRaiz(objArbolVueloTurista.Insertar(objArbolVueloTurista.getRaiz(), nuevo));
            ActualizarTabla();
            LimpiarCampos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al registrar: " + e.getMessage());
        }
    }//GEN-LAST:event_btn_RegistrarActionPerformed

    private void btn_EditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_EditarActionPerformed
        try {
            int codigo = Integer.parseInt(cbo_codigo.getSelectedItem().toString());
            VuelosTurista vuelo = objArbolVueloTurista.Buscar(objArbolVueloTurista.getRaiz(), codigo);

            if (vuelo != null) {
                String clase = txt_clase.getText();
              
                
                
                vuelo.setClase(clase);
                
                DAO_VuelosTuristas.Actualizar(vuelo);
                objArbolVueloTurista.Listar(tbl_vuelosturista);

                JOptionPane.showMessageDialog(this, "Vuelo actualizado correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró el vuelo con ese código.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al editar: " + e.getMessage());
        }


    }//GEN-LAST:event_btn_EditarActionPerformed

    private void btn_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_EliminarActionPerformed
        int fila = tbl_vuelosturista.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(null, "Selecciona un vuelo de la tabla.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(null, "¿Eliminar este vuelo?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            int codigo = Integer.parseInt(tbl_vuelosturista.getValueAt(fila, 0).toString());
            VuelosTurista vuelo = objArbolVueloTurista.Buscar(objArbolVueloTurista.getRaiz(), codigo);
            if (vuelo == null) {
                JOptionPane.showMessageDialog(null, "No se encontró el vuelo en el árbol.");
                return;
            }

            DAO_VuelosTuristas.Eliminar(vuelo);
            objArbolVueloTurista.setRaiz(objArbolVueloTurista.Eliminar(objArbolVueloTurista.getRaiz(), codigo));
            ActualizarTabla();
            LimpiarCampos();
            objArbolVueloTurista.ListarCbo(cbo_codigo, TablaHash1);

            JOptionPane.showMessageDialog(null, "Vuelo eliminado correctamente.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al eliminar: " + ex.getMessage());
        }

    }//GEN-LAST:event_btn_EliminarActionPerformed

    private void btn_ListarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ListarActionPerformed
        try {
            int codigo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el código del vuelo a consultar"));
            VuelosTurista vuelo = objArbolVueloTurista.Buscar(objArbolVueloTurista.getRaiz(), codigo);

            if (vuelo != null) {
                String mensaje = "Clase: " + vuelo.getClase() + "\n"
                        + "Código Vuelo: " + vuelo.getCodigoVuelo() + "\n"
                        + "Nro Vuelo: " + vuelo.getVuelos_NumeroVuelo()+
                  "CodigoViaje_contratado: " + vuelo.getViajesContratados_CodigoViaje();
                JOptionPane.showMessageDialog(this, mensaje);
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró el vuelo con ese código.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }

    }//GEN-LAST:event_btn_ListarActionPerformed

    private void tbl_vuelosturistaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_vuelosturistaMouseClicked
        comboCodigo.removeAllElements();
        objArbolVueloTurista.InordenCBO(objArbolVueloTurista.getRaiz(), comboCodigo, TablaHash1);

        int pos = tbl_vuelosturista.getSelectedRow();
        if (pos != -1) {
            int codigo = Integer.parseInt(tbl_vuelosturista.getValueAt(pos, 0).toString());
            if (TablaHash1.containsKey(codigo)) {
                VuelosTurista vuelo = (VuelosTurista) TablaHash1.get(codigo);
                txt_clase.setText(vuelo.getClase());
            } else {
                JOptionPane.showMessageDialog(this, "Vuelo no encontrado en la tabla hash.");
            }
        }
    }//GEN-LAST:event_tbl_vuelosturistaMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened

        DAO_VuelosTuristas.Consultar_Todos(objArbolVueloTurista);
        objArbolVueloTurista.ListarCbo(cbo_codigo, TablaHash1);
        objArbolVueloTurista.Listar(tbl_vuelosturista);
        
   
        DAO_Vuelos.ConsultarParaCombo(cbo_numVuelo, objArbol_Vuelos, TablaHash2);
        DAO_ViajesContratados.ConsultarParaCombo(cbo_codviaje, objArbol_ViajeContratado, TablaHash3);
    }//GEN-LAST:event_formWindowOpened

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDialog_VuelosTuristas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDialog_VuelosTuristas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDialog_VuelosTuristas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDialog_VuelosTuristas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDialog_VuelosTuristas dialog = new JDialog_VuelosTuristas(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Opciones;
    private javax.swing.JButton btn_Editar;
    private javax.swing.JButton btn_Eliminar;
    private javax.swing.JButton btn_Listar;
    private javax.swing.JButton btn_Registrar;
    private javax.swing.JComboBox<String> cbo_codigo;
    private javax.swing.JComboBox<String> cbo_codviaje;
    private javax.swing.JComboBox<String> cbo_numVuelo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_vuelosturista;
    private javax.swing.JTextField txt_clase;
    // End of variables declaration//GEN-END:variables
}
