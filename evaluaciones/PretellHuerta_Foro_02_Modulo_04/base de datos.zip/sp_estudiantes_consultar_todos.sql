CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_estudiantes_consultar_todos`()
BEGIN
	SELECT *
    FROM estudiantes
    WHERE eliminado =0;
END