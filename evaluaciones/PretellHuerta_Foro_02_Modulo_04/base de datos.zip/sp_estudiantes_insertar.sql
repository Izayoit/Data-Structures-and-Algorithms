CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_estudiantes_insertar`(
	IN dato1 VARCHAR(60), IN dato2 VARCHAR(60), IN dato3 VARCHAR(60), IN dato4 VARCHAR(60), IN dato5 INT, IN dato6 INT,OUT dato7 INT
)
BEGIN
	INSERT INTO estudiantes(dni, nombres,apellidos ,correo ,telefono,id_carrera)
    VALUE(dato1,dato2,dato3,dato4,dato5,dato6);
    SET  dato7 =last_insert_id();
END