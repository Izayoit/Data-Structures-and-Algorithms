CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_estudiantes_eliminar`(
	IN dato1 INT
)
BEGIN
	UPDATE estudiantes SET eliminado =1
    WHERE id_estudiante=dato1;
END